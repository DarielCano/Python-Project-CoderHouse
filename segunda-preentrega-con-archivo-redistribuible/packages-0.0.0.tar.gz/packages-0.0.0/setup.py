from setuptools import setup

setup(
    name="packages",
    description="Clase cliente con metodos para su acceso",
    author="Dariel Cano Gonzalez",
    author_email="dariel.cano1992@gmail.com",
    
    packages=["packages"]
)