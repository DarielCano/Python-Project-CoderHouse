# PRESENTACION

Proyecto de CoderHouse Primera Preentrega, Segunda Prenetrega

# DESCRIPCION

- Primera Preentrega:
  Simular login y registro de usuarios y mostrar la información de los mismos en consola

Segunda Preentrega:

- Simular el modelado de cliente en una página de compras, con minimo 4 atributos y herencia opcional.
  Utilizar paquetes redistribuibles

## AUTOR

- [@DarielCano](https://www.github.com/DarieCano)

-[@cv](https://drive.google.com/file/d/1tTkd27bLXFh6M9vCI3uco_lMszwkZcl6/view?usp=share_link)
